"""
@file   : x.py
@time   : 2025-12-06
"""
from sklearn.datasets import load_iris
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

pd.set_option('display.max_columns', None)

iris = load_iris()
feature_names = iris['feature_names']
X = iris.data
Y = iris.target

df = pd.DataFrame(X, columns=feature_names)
df['label'] = Y

# pairplot画相关性图
"""
sns.pairplot(df)
plt.savefig('xx.png')
"""

# print(df.corr())  # 皮尔逊相关系数   cov / xx
sns.heatmap(df.corr())   # df.corr()算协方差
plt.savefig('yy.png')


