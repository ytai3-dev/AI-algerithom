import pandas as pd
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

pd.set_option('display.max_columns', None)
iris = load_iris()
feature_names = iris['feature_names']
X = iris.data
Y = iris.target

df = pd.DataFrame(X, columns=feature_names)
df['label'] = Y

# 决策树
rf = RandomForestClassifier()
rf.fit(X, Y)
print(rf.feature_importances_)  # [0.1097378  0.0259785  0.44758284 0.41670085]


# 逻辑回归
"""
X = df.drop("label", axis=1)
Y = df['label']

lr = LogisticRegression(random_state=43)
lr.fit(X, Y)


res = lr.coef_  # 特征系数
# print(res)

res = res.mean(axis=0)
# print(res)

for v in res:
    print(abs(v))
"""
# from xgboost import XGBClassifier
# xgb = XGBClassifier()
# print(xgb.feature_importance_)


